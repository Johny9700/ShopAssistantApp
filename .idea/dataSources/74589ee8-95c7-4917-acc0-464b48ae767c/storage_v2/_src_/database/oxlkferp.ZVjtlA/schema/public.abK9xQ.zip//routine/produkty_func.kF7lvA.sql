create function produkty_func()
  returns trigger
language plpgsql
as $$
BEGIN
        NEW.id_produktu := nextval('produkty_seq');
        Return NEW;
    END;
$$;

alter function produkty_func()
  owner to oxlkferp;

