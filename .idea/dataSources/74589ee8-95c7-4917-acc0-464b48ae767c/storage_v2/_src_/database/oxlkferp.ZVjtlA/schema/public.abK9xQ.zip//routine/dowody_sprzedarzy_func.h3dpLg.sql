create function dowody_sprzedarzy_func()
  returns trigger
language plpgsql
as $$
BEGIN
        NEW.id_dowodu_sprzedazy := nextval('dowody_sprzedarzy_seq');
        Return NEW;
    END;
$$;

alter function dowody_sprzedarzy_func()
  owner to oxlkferp;

