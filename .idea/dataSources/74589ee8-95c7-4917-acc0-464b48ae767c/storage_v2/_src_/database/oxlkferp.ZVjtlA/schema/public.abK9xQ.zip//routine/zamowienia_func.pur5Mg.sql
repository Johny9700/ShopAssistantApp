create function zamowienia_func()
  returns trigger
language plpgsql
as $$
BEGIN
        NEW.id_zamowienia := nextval('zamowienia_seq');
        Return NEW;
    END;
$$;

alter function zamowienia_func()
  owner to oxlkferp;

