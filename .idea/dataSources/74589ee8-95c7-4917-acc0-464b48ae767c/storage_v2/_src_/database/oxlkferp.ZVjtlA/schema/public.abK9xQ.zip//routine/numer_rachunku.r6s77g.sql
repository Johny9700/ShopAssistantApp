create function numer_rachunku(rodzaj text)
  returns text
language plpgsql
as $$
DECLARE returnVal TEXT;
  DECLARE numer INTEGER;
BEGIN
  IF rodzaj = 'F' THEN
    numer := nextval('paragony_seq');
    returnVal := 'FAV-' || numer;
  ELSE
    numer := nextval('faktury_seq');
    returnVal := 'P' || numer;
  END IF;
  Return returnVal;
END;
$$;

alter function numer_rachunku(text)
  owner to oxlkferp;

