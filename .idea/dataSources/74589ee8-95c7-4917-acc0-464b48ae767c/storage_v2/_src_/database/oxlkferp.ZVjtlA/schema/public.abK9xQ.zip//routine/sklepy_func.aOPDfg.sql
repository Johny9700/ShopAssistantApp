create function sklepy_func()
  returns trigger
language plpgsql
as $$
BEGIN
        NEW.id_sklepu := nextval('sklepy_seq');
        Return NEW;
    END;
$$;

alter function sklepy_func()
  owner to oxlkferp;

