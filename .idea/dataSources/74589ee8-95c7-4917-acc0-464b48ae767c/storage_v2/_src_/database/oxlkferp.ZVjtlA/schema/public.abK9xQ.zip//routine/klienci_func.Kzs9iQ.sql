create function klienci_func()
  returns trigger
language plpgsql
as $$
BEGIN
        NEW.id_klienta := nextval('klienci_seq');
        Return NEW;
    END;
$$;

alter function klienci_func()
  owner to oxlkferp;

