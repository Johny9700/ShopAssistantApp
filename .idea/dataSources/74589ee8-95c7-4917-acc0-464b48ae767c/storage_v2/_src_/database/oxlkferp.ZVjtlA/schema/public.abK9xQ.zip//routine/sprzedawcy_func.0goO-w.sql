create function sprzedawcy_func()
  returns trigger
language plpgsql
as $$
BEGIN
        NEW.id_sprzedawcy := nextval('sprzedawcy_seq');
        Return NEW;
    END;
$$;

alter function sprzedawcy_func()
  owner to oxlkferp;

